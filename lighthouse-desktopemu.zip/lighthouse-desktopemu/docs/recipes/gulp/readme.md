# Gulp recipe for Lighthouse
 
## Run

- `npm install`
- `npm start`
