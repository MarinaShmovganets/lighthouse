/**
 * Internal dependencies
 */
import './page-template-modal';
