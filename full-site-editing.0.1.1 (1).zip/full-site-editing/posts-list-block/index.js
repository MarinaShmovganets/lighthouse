/**
 * Internal dependencies
 */
import './blocks/posts-list';
