/**
 * Internal dependencies
 */
import './blocks/post-content';
import './blocks/template';
import './plugins/template-selector-sidebar';
